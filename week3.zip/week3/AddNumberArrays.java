/* 
 * file	  : Quadratic.java
 * author : Emily Kabat
 * created: 2.14.19
 * desc	  : This program implements quadratic formula
 */ 

import java.util.Scanner;

public class AddNumberArrays {

	public static void main(String[] args) {
		
		System.out.println("\t\tWelcome to Quadratic 3000");
		System.out.println("This program implements the quadratic formula");
		
		Scanner scnr = new Scanner(System.in);
	
		double a;
		double b;
		double c;
		double discriminant;
		double root1;
		double root2;
		
		System.out.println("Enter a: ");
		a = scnr.nextDouble();
		System.out.println("Enter b: ");
		b = scnr.nextDouble();
		System.out.println("Enter c: ");
		c = scnr.nextDouble();
		
		discriminant = Math.sqrt(Math.pow(b, 2.0) - (4.0 * a * c));
		root1 = (-b + discriminant) / (2.0 * a);
		root2 = (-b - discriminant) / (2.0 * a);
		
		System.out.println("root1 = " + root1);
		System.out.println("root2 = " + root2);
		
	}

}